<script setup>
 import Navbar from '@/components/Navbar.vue';
 import Product from '@/components/Product.vue';
</script>

<template>
  <Navbar/>
  <main>
    <h1 class="text-center">Nuestros Productos</h1>
    <Product/>
  </main>
</template>
