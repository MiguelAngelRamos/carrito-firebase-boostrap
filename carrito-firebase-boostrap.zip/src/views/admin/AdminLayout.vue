<script setup>
import Navbar from '@/components/Navbar.vue';
</script>

<template>
  <Navbar/>
  <div class="container">
    <RouterView/>
  </div>
</template>