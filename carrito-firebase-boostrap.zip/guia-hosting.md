## Instalar firebase-tools

```sh
 npm install -g firebase-tools
```


## Inicializa el proyecto
Abre una ventana de la terminal y navega a un directorio raíz para tu app web (si no tienes uno, deberás crearlo).

```sh
firebase login
```
## Inicia el proyecto

Ejecuta el siguiente comando en el directorio raíz de tu app:

```sh
firebase init
```
## Pregunta

- Are you ready to proceed? (Y/n)  vas a responder que si (Y)
- Use an existing project -> es lo que vamos a seleccionar